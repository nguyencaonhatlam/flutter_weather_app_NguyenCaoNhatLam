class LocationModel {
  final double latitude;
  final double longitude;
  final String? cityName;
  final String? country;

  LocationModel({
    required this.latitude,
    required this.longitude,
    this.cityName,
    this.country,
  });

  factory LocationModel.fromPosition(dynamic position) {
    return LocationModel(
      latitude: position.latitude,
      longitude: position.longitude,
    );
  }

  factory LocationModel.fromJson(Map<String, dynamic> json) {
    return LocationModel(
      latitude: json['lat']?.toDouble() ?? 0,
      longitude: json['lon']?.toDouble() ?? 0,
      cityName: json['name'],
      country: json['country'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'lat': latitude,
      'lon': longitude,
      'name': cityName,
      'country': country,
    };
  }
}