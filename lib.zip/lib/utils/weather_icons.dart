import 'package:flutter/material.dart';

class WeatherIcons {
  static IconData getIcon(String condition) {
    switch (condition.toLowerCase()) {
      case 'clear':
        return Icons.wb_sunny;

      case 'clouds':
        return Icons.cloud;

      case 'rain':
      case 'drizzle':
        return Icons.umbrella;

      case 'thunderstorm':
        return Icons.flash_on;

      case 'snow':
        return Icons.ac_unit;

      case 'mist':
      case 'fog':
      case 'haze':
        return Icons.cloud_queue;

      case 'smoke':
        return Icons.smoke_free;

      case 'dust':
      case 'sand':
      case 'ash':
        return Icons.grain;

      case 'squall':
      case 'tornado':
        return Icons.toys;

      default:
        return Icons.wb_cloudy;
    }
  }

  static Color getColor(String condition) {
    switch (condition.toLowerCase()) {
      case 'clear':
        return Colors.orange;

      case 'clouds':
        return Colors.blueGrey;

      case 'rain':
      case 'drizzle':
        return Colors.blue;

      case 'thunderstorm':
        return Colors.deepPurple;

      case 'snow':
        return Colors.lightBlueAccent;

      case 'mist':
      case 'fog':
      case 'haze':
        return Colors.grey;

      default:
        return Colors.grey;
    }
  }
}