class AppConstants {
  static const String openWeatherApiKey = "YOUR_API_KEY";

  static const String baseUrl = "https://api.openweathermap.org/data/2.5";

  static const String currentWeatherEndpoint = "/weather";
  static const String forecastEndpoint = "/forecast";

  static const String defaultUnits = "metric";

  static const String defaultLang = "vi";

  static const int timeout = 10000;

  static const String cacheWeatherKey = "CACHE_WEATHER";
  static const String cacheForecastKey = "CACHE_FORECAST";

  static const String tempUnitKey = "tempUnit";
  static const String windUnitKey = "windUnit";
  static const String timeFormatKey = "is24Hour";

  static const String favoritesKey = "favorites";
  static const String historyKey = "history";

  static const String lastLocationKey = "last_location";
}