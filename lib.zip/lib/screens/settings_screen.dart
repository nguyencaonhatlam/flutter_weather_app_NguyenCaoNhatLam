import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  String tempUnit = "C";
  String windUnit = "m/s";
  bool is24Hour = true;

  @override
  void initState() {
    super.initState();
    loadSettings();
  }

  Future<void> loadSettings() async {
    final prefs = await SharedPreferences.getInstance();

    setState(() {
      tempUnit = prefs.getString("tempUnit") ?? "C";
      windUnit = prefs.getString("windUnit") ?? "m/s";
      is24Hour = prefs.getBool("is24Hour") ?? true;
    });
  }

  Future<void> saveSettings() async {
    final prefs = await SharedPreferences.getInstance();

    await prefs.setString("tempUnit", tempUnit);
    await prefs.setString("windUnit", windUnit);
    await prefs.setBool("is24Hour", is24Hour);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Cài đặt"),
      ),
      body: ListView(
        children: [
          const ListTile(
            title: Text("Đơn vị nhiệt độ"),
          ),
          RadioListTile(
            title: const Text("Celsius (°C)"),
            value: "C",
            groupValue: tempUnit,
            onChanged: (value) {
              setState(() {
                tempUnit = value!;
              });
              saveSettings();
            },
          ),
          RadioListTile(
            title: const Text("Fahrenheit (°F)"),
            value: "F",
            groupValue: tempUnit,
            onChanged: (value) {
              setState(() {
                tempUnit = value!;
              });
              saveSettings();
            },
          ),

          const Divider(),

          const ListTile(
            title: Text("Đơn vị gió"),
          ),
          RadioListTile(
            title: const Text("m/s"),
            value: "m/s",
            groupValue: windUnit,
            onChanged: (value) {
              setState(() {
                windUnit = value!;
              });
              saveSettings();
            },
          ),
          RadioListTile(
            title: const Text("km/h"),
            value: "km/h",
            groupValue: windUnit,
            onChanged: (value) {
              setState(() {
                windUnit = value!;
              });
              saveSettings();
            },
          ),
          RadioListTile(
            title: const Text("mph"),
            value: "mph",
            groupValue: windUnit,
            onChanged: (value) {
              setState(() {
                windUnit = value!;
              });
              saveSettings();
            },
          ),

          const Divider(),
          
          SwitchListTile(
            title: const Text("Định dạng 24 giờ"),
            value: is24Hour,
            onChanged: (value) {
              setState(() {
                is24Hour = value;
              });
              saveSettings();
            },
          ),
        ],
      ),
    );
  }
}