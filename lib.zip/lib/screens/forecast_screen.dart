import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/weather_provider.dart';
import '../widgets/hourly_forecast_list.dart';
import '../widgets/daily_forecast_card.dart';
import '../widgets/loading_shimmer.dart';
import '../widgets/error_widget.dart';

class ForecastScreen extends StatelessWidget {
  const ForecastScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<WeatherProvider>();

    return Scaffold(
      appBar: AppBar(
        title: const Text("Dự báo thời tiết"),
      ),
      body: _buildBody(provider),
    );
  }

  Widget _buildBody(WeatherProvider provider) {

    if (provider.state == WeatherState.loading) {
      return const LoadingShimmer();
    }

    if (provider.state == WeatherState.error) {
      return ErrorWidgetCustom(
        message: provider.errorMessage,
        onRetry: () {
          provider.refreshWeather();
        },
      );
    }

    if (provider.forecast.isEmpty) {
      return const Center(
        child: Text("Không có dữ liệu dự báo"),
      );
    }

    return RefreshIndicator(
      onRefresh: () => provider.refreshWeather(),
      child: SingleChildScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        child: Column(
          children: [
            HourlyForecastList(
              forecasts: provider.forecast,
            ),

            const SizedBox(height: 10),

            DailyForecastSection(
              forecasts: provider.forecast,
            ),
          ],
        ),
      ),
    );
  }
}