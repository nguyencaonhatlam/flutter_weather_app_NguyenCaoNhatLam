import 'package:flutter/material.dart';
import '../models/forecast_model.dart';

class HourlyForecastList extends StatelessWidget {
  final List<ForecastModel> forecasts;

  const HourlyForecastList({required this.forecasts});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 120,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: forecasts.length > 10 ? 10 : forecasts.length,
        itemBuilder: (context, index) {
          final item = forecasts[index];
          return Container(
            width: 80,
            margin: EdgeInsets.all(8),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text("${item.dateTime.hour}:00"),
                SizedBox(height: 8),
                Text("${item.temperature.round()}°"),
              ],
            ),
          );
        },
      ),
    );
  }
}