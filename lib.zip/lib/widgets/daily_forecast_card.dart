import 'package:flutter/material.dart';
import '../models/forecast_model.dart';

class DailyForecastSection extends StatelessWidget {
  final List<ForecastModel> forecasts;

  const DailyForecastSection({required this.forecasts});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: forecasts.take(5).map((item) {
        return ListTile(
          title: Text(
              "${item.dateTime.day}/${item.dateTime.month}"),
          subtitle: Text(item.description),
          trailing: Text("${item.tempMax.round()}°"),
        );
      }).toList(),
    );
  }
}